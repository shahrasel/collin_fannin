<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Tickets__Tickets_Pro' );


	class TribeEventsTicketsPro extends Tribe__Events__Tickets__Tickets_Pro {

	}